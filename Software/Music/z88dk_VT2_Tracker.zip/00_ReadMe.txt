z88dk VT2 Tracker
Taken from https://github.com/z88dk/z88dk/tree/master/examples/sound/vt2 and slightly modified.

You can take any .pt3 music file, e.g. from...
https://zxart.ee/eng/music/database/
...and create a program file that will play this sound on any z88dk target that supports AY sound.

Instructions:
- Put the .pt3 file in the directory
- Replace the .pt3 file name in sound.asm
- Modify main.c so that it will display the artist and the song name
- Use compile_vt2_...bat to compile the file for your desired target (modify z88root in the .bat file so that it points to your z88dk path).

----------
RobertK (RetroBertie@outlook.com)
https://drive.google.com/drive/folders/1J3synVV-5PiKcZs9oFsY-6CqWDRKv7X2
